﻿<?php

include_once './web/index.php';

?>
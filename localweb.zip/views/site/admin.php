<div>
	<a href='/?r=news/index'>
		<h4>Управление новостями</h4>
	</a>
	<a href='/?r=marathonbaners/index'>
		<h4>Управление банерами марафона</h4>
	</a>
</div>
<?php

$this->title = 'Goldensplit | Игры';

?>

<div id="vrazrabotke">
	<h1>РАЗДЕЛ В РАЗРАБОТКЕ</h1>
	<img id="mariorazrabotka" src="/web/MyImg/mario-holding-cube.png"/>
</div>
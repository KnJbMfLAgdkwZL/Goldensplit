<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=twitch_marathon',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
